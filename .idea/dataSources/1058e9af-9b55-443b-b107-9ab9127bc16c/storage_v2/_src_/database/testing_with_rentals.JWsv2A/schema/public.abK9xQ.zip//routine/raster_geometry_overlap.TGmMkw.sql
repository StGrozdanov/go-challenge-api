create function raster_geometry_overlap(raster, geometry) returns boolean
    immutable
    strict
    parallel safe
    language sql
as
$$select $1::public.geometry OPERATOR(public.&&) $2$$;

alter function raster_geometry_overlap(raster, geometry) owner to root;

