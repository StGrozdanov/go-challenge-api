create function st_summarystats(rastertable text, rastercolumn text, exclude_nodata_value boolean) returns summarystats
    stable
    strict
    parallel safe
    language sql
as
$$ SELECT public._ST_summarystats($1, $2, 1, $3, 1) $$;

comment on function st_summarystats(text, text, boolean) is 'args: rastertable, rastercolumn, exclude_nodata_value - Returns summarystats consisting of count, sum, mean, stddev, min, max for a given raster band of a raster or raster coverage. Band 1 is assumed is no band is specified.';

alter function st_summarystats(text, text, boolean) owner to root;

