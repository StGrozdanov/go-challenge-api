create function st_combine_bbox(box3d, geometry) returns box3d
    immutable
    language sql
as
$$ SELECT public._postgis_deprecate('ST_Combine_BBox', 'ST_CombineBbox', '2.2.0');
    SELECT public.ST_CombineBbox($1,$2);
  $$;

alter function st_combine_bbox(box3d, geometry) owner to root;

