create function st_estimated_extent(text, text) returns box2d
    immutable
    strict
    language sql
as
$$ SELECT public._postgis_deprecate('ST_Estimated_Extent', 'ST_EstimatedExtent', '2.1.0');
    -- We use security invoker instead of security definer
    -- to prevent malicious injection of a same named different function
    -- that would be run under elevated permissions
    SELECT public.ST_EstimatedExtent($1, $2);
  $$;

alter function st_estimated_extent(text, text) owner to root;

