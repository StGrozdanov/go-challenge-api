create function st_tile(rast raster, nband integer, width integer, height integer, padwithnodata boolean DEFAULT false, nodataval double precision DEFAULT NULL::double precision) returns SETOF raster
    immutable
    parallel safe
    language sql
as
$$ SELECT public._ST_tile($1, $3, $4, ARRAY[$2]::integer[], $5, $6) $$;

comment on function st_tile(raster, integer, integer, integer, boolean, double precision) is 'args: rast, nband, width, height, padwithnodata=FALSE, nodataval=NULL - Returns a set of rasters resulting from the split of the input raster based upon the desired dimensions of the output rasters.';

alter function st_tile(raster, integer, integer, integer, boolean, double precision) owner to root;

